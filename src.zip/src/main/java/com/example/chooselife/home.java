package com.example.chooselife;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class home extends AppCompatActivity {

    ImageView iv, iv1,iv2;
    BottomNavigationView bottomNavigationView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        iv= findViewById(R.id.imageView6);
        iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(),planner.class);
                startActivity(i);
            }
        });
        iv1= findViewById(R.id.imageView7);
        iv1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i1 = new Intent(getApplicationContext(),activities.class);
                startActivity(i1);
            }
        });
        iv2= findViewById(R.id.imageView8);
        iv2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i2 = new Intent(getApplicationContext(),mood.class);
                startActivity(i2);
            }
        });
        bottomNavigationView= findViewById(R.id.bottom_navigator);

        bottomNavigationView.setSelectedItemId(R.id.home);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch(item.getItemId())
                {
                    case R.id.report:
                        startActivity(new Intent(getApplicationContext(), report.class));
                        overridePendingTransition(0,0);
                        return true;

                    case R.id.heart:
                        startActivity(new Intent(getApplicationContext(), hrv.class));
                        overridePendingTransition(0,0);
                        return true;


                    case R.id.home:

                        return true;

                    case R.id.profile:
                        startActivity(new Intent(getApplicationContext(),profile.class));
                        overridePendingTransition(0,0);
                        return true;
                }


                return false;
            }
        });
    }
}